// Copyright (C) 2004 by William D Kalies. All rights reserved.
//
#define DIM 3
