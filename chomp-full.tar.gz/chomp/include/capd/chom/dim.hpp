// Copyright (C) 2004 by William D Kalies. All rights reserved.
//
// Adaptation to the multiengine enviroment by Marian Mrozek
#include "capd/homologicalAlgebra/embeddingDim.h"
//#define DIM 4
#define DIM EMBEDDING_DIM
#define MAX_CHOM_DIM 12
extern int chomDIM;
